# ----------------------------------------------------------------------------
# - Conversion from goproblems html files to multigame sgf files - gopb2sgf.pl
# ----------------------------------------------------------------------------

use strict;

=pod -------------------------------------------------------------------------

--- Calling convention

perl -w gopb2sgf.pl <directory> [bygenre] [bydifficulty] [bystring=<string>] [cleanCR]

<directory>
   directory with goproblems html files, must be present
[bygenre]
   if present, dispatches problems by genre
[bydifficulty]
   if present, dispatches problems by difficulty
[bystring=<string>]
   if present, ignores bygenre and bydifficulty options. Allows to gather in a single
   sgf file all problems where <string> is present. no space around the equal character!
[cleanCR]
   if present, delete all CR properties in patterns like B[xy]C[xy] from 
   cgoban
   
Parameters are case sensitive. Sgf files are created with name gp.sgf or
gp-[difficulty]-[genre].sgf

--- Examples

>perl -w gopb2sgf.pl .\
   gathers all problem html files in the current directory in a single sgf file
   
>perl -w gopb2sgf.pl c:\goproblems bygenre bydifficulty
   dispatches html problem files from c:\goproblems directory onto one file per
   couple (genre, difficulty) 
   
>perl -w gopb2sgf.pl goproblems.com bystring=SZ[4] cleanCR
   gathers all 4x4 problems into gp.sgf and delete CRs
   
--- Syntax checking

This script ignores the files with the following sgf syntax errors:
- unbalanced parentheses
- unbalanced brackets
- invalid property names (empty, lowercase or too long)
This allows Drago to read completely the generated files.

--- Copyright and disclaimers

Copyright (C) Gilles Arcas 2004. 
Freeware, all rights reserved, all warranties disclaimed.

gilles_arcas@hotmail.com
www.geocities.com/wwwdrago

=cut -------------------------------------------------------------------------

# analyse script parameters

my ($gpDir, $Dispatch, $DispatchString, $CleanCR, @pblist);

{  my ($DispatchByGenre, $DispatchByDifficulty, $DispatchByString, $i);

   ExitIf(!@ARGV, "Directory absent, see documentation in script file");

   $gpDir                = $ARGV[0];
   $DispatchByGenre      = 0;
   $DispatchByDifficulty = 0;
   $DispatchByString     = 0;
   $CleanCR              = 0;
   
   for ($i = 1; $i <= $#ARGV; $i++) {
      $DispatchByGenre      = 1 if $ARGV[$i] eq 'bygenre';
      $DispatchByDifficulty = 2 if $ARGV[$i] eq 'bydifficulty';
      $DispatchByString     = 4 if $ARGV[$i] =~ /^bystring/;
      $CleanCR              = 1 if $ARGV[$i] eq 'cleanCR';

      ($DispatchString) = ($1)  if $ARGV[$i] =~ /^bystring=(.*)/;
   }
   $Dispatch = $DispatchByGenre + $DispatchByDifficulty + $DispatchByString;
}

# get problem file list

ExitIf(!opendir(DIR, $gpDir), "Cannot open dir $gpDir");

@pblist = sort { $a <=> $b }              # sort 
             map  /(\d+)/,                # the numbers
                grep /^prob.*\.html$/,    # of problem files 
                   readdir DIR;           # in input directory

closedir DIR;
ExitIf(!@pblist, "No problem files in directory $gpDir\n"); 

# scan each file

my (%pbhash, $pb);

foreach $pb (@pblist) {
   my ($lines, $sgf, $dif, $genre, $key, $s, $n, $i, $parOk);
   
   $pb = "prob${pb}.html";
   
   next if SkipFile($pb, !open(F, "goproblems.com/$pb"), 'Cannot open file');
   
   # get genre, difficulty and sgf data
   
   $lines = join ('', <F>);
   ($genre) = ($lines =~ /<td class=prob>\n *Genre:\n<\/td>\n<td>\n *([a-z ]*)/s);
   ($dif)   = ($lines =~ /<td class=prob>\n *Difficulty:\n<\/td>\n<td>[^(]*\((\w*)\)/s);
   ($sgf)   = ($lines =~ /<param name="sgf" value="(.*)"><\/applet>/s);
   
   next if SkipFile($pb, !defined($sgf)    , 'no SGF data');
   next if SkipFile($pb, $sgf !~ /\([^;]*;/, 'no SGF data');
   
   # delete all slashed chars
   
   $s = $sgf;
   $s =~ s/\\.//sg;
   
   # verify property names
   
   next if SkipFile($pb, $s =~ /;\s*\[/        ?1:0, 'empty property name');
   next if SkipFile($pb, $s =~ /;[a-z]*\[/     ?1:0, 'lowercase property name');
   next if SkipFile($pb, $s =~ /\]\s*[a-z]+\[/ ?1:0, 'lowercase property name');
   next if SkipFile($pb, $s =~ /;[A-Z]{3,}\[/  ?1:0, 'property name too long');
   next if SkipFile($pb, $s =~ /\]\s*[A-Z]{3,}/?1:0, 'property name too long');
   
   # delete all property values
            
   $s =~ s/\[[^]]*\]//sg;
   
   # verify brackets
   
   next if SkipFile($pb, $s =~ /[[\]]/?1:0, 'unexpected bracket');
   
   # verify parentheses 
   
   for ($i = 0, $n = 0, $parOk = 1; $i < length($s); $i++) {
      my ($c) = substr($s, $i, 1);
      
      $n++ if $c eq '(';
      $n-- if $c eq ')';
      
      if ($n < 0) {
         $parOk = 0;
         last;
      }
   }
   next if SkipFile($pb, $parOk == 0 || $n != 0, 'unbalanced parentheses');
   
   # ignore if doesn't comply bystring
   
   next if $Dispatch >= 4 && index($sgf, $DispatchString) < 0;
   
   # add filename to game comment
   
   if ($sgf !~ /GC\[/) {
      $sgf =~ s|\([^;]*;|(;GC[goproblems:$pb]|;
   }
   else {
      $sgf =~ s|GC\[|GC[goproblems:$pb\n|;
   }
   
   # clean CR properties if required
   
   if ($CleanCR) {
      $sgf =~ s/\bB\s*(\[\w\w\])([^;]*)\bCR\s*\1/B$1$2/sg;
      $sgf =~ s/\bW\s*(\[\w\w\])([^;]*)\bCR\s*\1/W$1$2/sg;
   }
   
   # compute hash key and store
   
   $key = "gp"             if $Dispatch == 0 ||$Dispatch >= 4;
   $key = "gp-$genre"      if $Dispatch == 1;
   $key = "gp-$dif"        if $Dispatch == 2;
   $key = "gp-$genre-$dif" if $Dispatch == 3;

   $pbhash{$key} = !defined $pbhash{$key} ? $sgf : $pbhash{$key} . "\n" . $sgf;
}

# save all files

foreach (keys %pbhash) {
   open F, ">$_.sgf";
   printf F "%s", $pbhash{$_};
   close F;
}
exit 0;

# Exit and skip

sub ExitIf {
   my ($test, $msg) = @_;
   
   if ($test) { 
      printf "\n** gopb2sgf : $msg\n";
      exit 1;
   }
}   

sub SkipFile {
   my ($pb, $test, $msg) = @_;
   
   printf "Skip $pb : $msg\n" if $test; 
   return $test;
}   

# ----------------------------------------------------------------------------

